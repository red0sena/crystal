---
dataset_info:
  features:
  - name: image_options
    dtype: image
  - name: caption_options
    sequence: string
  splits:
  - name: VG_Relation
    num_bytes: 5504595715.875
    num_examples: 23937
  - name: VG_Attribution
    num_bytes: 7210071865.5
    num_examples: 28748
  - name: COCO_Order
    num_bytes: 12092377388.75
    num_examples: 25010
  - name: Controlled_Images_A
    num_bytes: 456823630.0
    num_examples: 412
  - name: Controlled_Images_B
    num_bytes: 345149219.0
    num_examples: 408
  - name: COCO_QA_one_obj
    num_bytes: 1037548814.878
    num_examples: 2247
  - name: COCO_QA_two_obj
    num_bytes: 194516374.0
    num_examples: 440
  - name: VG_QA_one_obj
    num_bytes: 416478210.0
    num_examples: 1160
  - name: VG_QA_two_obj
    num_bytes: 108541211.0
    num_examples: 291
  download_size: 10754826706
  dataset_size: 27366102429.003
configs:
- config_name: default
  data_files:
  - split: VG_Relation
    path: data/VG_Relation-*
  - split: VG_Attribution
    path: data/VG_Attribution-*
  - split: COCO_Order
    path: data/COCO_Order-*
  - split: Controlled_Images_A
    path: data/Controlled_Images_A-*
  - split: Controlled_Images_B
    path: data/Controlled_Images_B-*
  - split: COCO_QA_one_obj
    path: data/COCO_QA_one_obj-*
  - split: COCO_QA_two_obj
    path: data/COCO_QA_two_obj-*
  - split: VG_QA_one_obj
    path: data/VG_QA_one_obj-*
  - split: VG_QA_two_obj
    path: data/VG_QA_two_obj-*
---
