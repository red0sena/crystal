---
dataset_info:
  features:
  - name: images
    sequence: image
  - name: problem
    dtype: string
  - name: answer
    dtype: string
  splits:
  - name: train
    num_bytes: 21901924.172
    num_examples: 6027
  - name: test
    num_bytes: 142173516.0
    num_examples: 1000
  download_size: 159468585
  dataset_size: 164075440.172
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: test
    path: data/test-*
---
