---
pretty_name: Oxford Flowers Dataset
source_datasets: https://www.robots.ox.ac.uk/~vgg/data/flowers
tags:
- flowers
- oxford
task_categories:
  - image-classification
  - unconditional-image-generation
license:
  - unknown
dataset_info:
  features:
  - name: image
    dtype: image
  - name: label
    dtype:
      class_label:
        names:
          '0': '1'
          '1': '10'
          '2': '100'
          '3': '101'
          '4': '102'
          '5': '11'
          '6': '12'
          '7': '13'
          '8': '14'
          '9': '15'
          '10': '16'
          '11': '17'
          '12': '18'
          '13': '19'
          '14': '2'
          '15': '20'
          '16': '21'
          '17': '22'
          '18': '23'
          '19': '24'
          '20': '25'
          '21': '26'
          '22': '27'
          '23': '28'
          '24': '29'
          '25': '3'
          '26': '30'
          '27': '31'
          '28': '32'
          '29': '33'
          '30': '34'
          '31': '35'
          '32': '36'
          '33': '37'
          '34': '38'
          '35': '39'
          '36': '4'
          '37': '40'
          '38': '41'
          '39': '42'
          '40': '43'
          '41': '44'
          '42': '45'
          '43': '46'
          '44': '47'
          '45': '48'
          '46': '49'
          '47': '5'
          '48': '50'
          '49': '51'
          '50': '52'
          '51': '53'
          '52': '54'
          '53': '55'
          '54': '56'
          '55': '57'
          '56': '58'
          '57': '59'
          '58': '6'
          '59': '60'
          '60': '61'
          '61': '62'
          '62': '63'
          '63': '64'
          '64': '65'
          '65': '66'
          '66': '67'
          '67': '68'
          '68': '69'
          '69': '7'
          '70': '70'
          '71': '71'
          '72': '72'
          '73': '73'
          '74': '74'
          '75': '75'
          '76': '76'
          '77': '77'
          '78': '78'
          '79': '79'
          '80': '8'
          '81': '80'
          '82': '81'
          '83': '82'
          '84': '83'
          '85': '84'
          '86': '85'
          '87': '86'
          '88': '87'
          '89': '88'
          '90': '89'
          '91': '9'
          '92': '90'
          '93': '91'
          '94': '92'
          '95': '93'
          '96': '94'
          '97': '95'
          '98': '96'
          '99': '97'
          '100': '98'
          '101': '99'
  splits:
  - name: train
    num_bytes: 308119477.446
    num_examples: 7169
  - name: test
    num_bytes: 43247670.14
    num_examples: 1020
  download_size: 346597973
  dataset_size: 351367147.58599997
---
# Dataset Card for "oxford-flowers"

[More Information needed](https://github.com/huggingface/datasets/blob/main/CONTRIBUTING.md#how-to-contribute-to-the-dataset-cards)