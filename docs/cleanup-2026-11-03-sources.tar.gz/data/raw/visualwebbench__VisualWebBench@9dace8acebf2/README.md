---
dataset_info:
- config_name: action_ground
  features:
  - name: id
    dtype: string
  - name: task_type
    dtype: string
  - name: website
    dtype: string
  - name: image
    dtype: image
  - name: image_size
    sequence: int64
  - name: raw_image
    dtype: image
  - name: options
    sequence:
      sequence: float64
  - name: instruction
    dtype: string
  - name: answer
    dtype: int64
  splits:
  - name: test
    num_bytes: 116178465
    num_examples: 103
  download_size: 116152003
  dataset_size: 116178465
- config_name: action_prediction
  features:
  - name: id
    dtype: string
  - name: task_type
    dtype: string
  - name: website
    dtype: string
  - name: image
    dtype: image
  - name: image_size
    sequence: int64
  - name: options
    sequence: string
  - name: bbox
    sequence: float64
  - name: elem_desc
    dtype: string
  - name: answer
    dtype: int64
  splits:
  - name: test
    num_bytes: 212320282
    num_examples: 281
  download_size: 212176366
  dataset_size: 212320282
- config_name: element_ground
  features:
  - name: id
    dtype: string
  - name: task_type
    dtype: string
  - name: website
    dtype: string
  - name: image
    dtype: image
  - name: image_size
    sequence: int64
  - name: raw_image
    dtype: image
  - name: options
    sequence:
      sequence: float64
  - name: elem_desc
    dtype: string
  - name: answer
    dtype: int64
  splits:
  - name: test
    num_bytes: 541444180
    num_examples: 413
  download_size: 425203495
  dataset_size: 541444180
- config_name: element_ocr
  features:
  - name: id
    dtype: string
  - name: task_type
    dtype: string
  - name: website
    dtype: string
  - name: image
    dtype: image
  - name: image_size
    sequence: int64
  - name: bbox
    sequence: float64
  - name: elem_desc
    dtype: string
  - name: answer
    dtype: string
  splits:
  - name: test
    num_bytes: 177127391
    num_examples: 245
  download_size: 177036578
  dataset_size: 177127391
- config_name: heading_ocr
  features:
  - name: id
    dtype: string
  - name: task_type
    dtype: string
  - name: website
    dtype: string
  - name: image
    dtype: image
  - name: image_size
    sequence: int64
  - name: bbox
    sequence: float64
  - name: answer
    dtype: string
  splits:
  - name: test
    num_bytes: 36406054
    num_examples: 46
  download_size: 36401829
  dataset_size: 36406054
- config_name: web_caption
  features:
  - name: id
    dtype: string
  - name: task_type
    dtype: string
  - name: website
    dtype: string
  - name: image
    dtype: image
  - name: image_size
    sequence: int64
  - name: answer
    dtype: string
  splits:
  - name: test
    num_bytes: 112890184
    num_examples: 134
  download_size: 112864700
  dataset_size: 112890184
- config_name: webqa
  features:
  - name: id
    dtype: string
  - name: task_type
    dtype: string
  - name: website
    dtype: string
  - name: image
    dtype: image
  - name: image_size
    sequence: int64
  - name: question
    dtype: string
  - name: answer
    sequence: string
  splits:
  - name: test
    num_bytes: 271769428
    num_examples: 314
  download_size: 100761418
  dataset_size: 271769428
configs:
- config_name: action_ground
  data_files:
  - split: test
    path: action_ground/test-*
- config_name: action_prediction
  data_files:
  - split: test
    path: action_prediction/test-*
- config_name: element_ground
  data_files:
  - split: test
    path: element_ground/test-*
- config_name: element_ocr
  data_files:
  - split: test
    path: element_ocr/test-*
- config_name: heading_ocr
  data_files:
  - split: test
    path: heading_ocr/test-*
- config_name: web_caption
  data_files:
  - split: test
    path: web_caption/test-*
- config_name: webqa
  data_files:
  - split: test
    path: webqa/test-*
license: apache-2.0
task_categories:
- image-to-text
- visual-question-answering
language:
- en
pretty_name: VisualWebBench
size_categories:
- 1K<n<10K
---



# VisualWebBench

Dataset for the paper: [VisualWebBench: How Far Have Multimodal LLMs Evolved in Web Page Understanding and Grounding?](https://arxiv.org/abs/2404.05955)

[**🌐 Homepage**](https://visualwebbench.github.io/) | [**🐍 GitHub**](https://github.com/VisualWebBench/VisualWebBench) | [**📖 arXiv**](https://arxiv.org/abs/2404.05955)


## Introduction

We introduce **VisualWebBench**, a multimodal benchmark designed to assess the **understanding and grounding capabilities of MLLMs in web scenarios**. VisualWebBench consists of **seven tasks**, and comprises **1.5K** human-curated instances from **139** real websites, covering 87 sub-domains. We evaluate 14 open-source MLLMs, Gemini Pro, Claude 3, and GPT-4V(ision) on WebBench, revealing significant challenges and performance gaps. Further analysis highlights the limitations of current MLLMs, including inadequate grounding in text-rich environments and subpar performance with low-resolution image inputs. We believe VisualWebBench will serve as a valuable resource for the research community and contribute to the creation of more powerful and versatile MLLMs for web-related applications.

![Alt text](https://raw.githubusercontent.com/VisualWebBench/VisualWebBench/main/assets/main.png)

## Benchmark Construction
We introduce VisualWebBench, a comprehensive multimodal benchmark designed to assess the capabilities of MLLMs in the web domain. Inspired by the human interaction process with web browsers, VisualWebBench consists of seven tasks that map to core abilities required for web tasks: captioning, webpage QA, heading OCR, element OCR, element grounding, action prediction, and action grounding, as detailed in the figure. The benchmark comprises 1.5K instances, all uniformly formulated in the QA style, making it easy to evaluate and compare the performance of different MLLMs.
![Alt text](https://raw.githubusercontent.com/VisualWebBench/VisualWebBench/main/assets/compare.png)
The proposed VisualWebBench possesses the following features:
- **Comprehensiveness**: VisualWebBench spans 139 websites with 1.5K samples, encompassing 12 different domains (e.g., travel, sports, hobby, lifestyle, animals, science, etc.) and 87 sub-domains.
- **Multi-granularity**: VisualWebBench assesses MLLMs at three levels: website-level, element-level, and action-level.
- **Multi-tasks**: WebBench encompasses seven tasks designed to evaluate the understanding, OCR, grounding, and reasoning capabilities of MLLMs.
- **High quality**: Quality is ensured through careful human verification and curation efforts.
![Alt text](https://raw.githubusercontent.com/VisualWebBench/VisualWebBench/main/assets/detail.png)

## Evaluation

We provide [evaluation code](https://github.com/VisualWebBench/VisualWebBench) for GPT-4V, Claude, Gemini, and LLaVA 1.6 series.

## Contact
- Junpeng Liu: [jpliu@link.cuhk.edu.hk](jpliu@link.cuhk.edu.hk)
- Yifan Song: [yfsong@pku.edu.cn](yfsong@pku.edu.cn)
- Xiang Yue: [xyue2@andrew.cmu.edu](xyue2@andrew.cmu.edu)

## Citation
If you find this work helpful, please cite out paper:
```
@misc{liu2024visualwebbench,
      title={VisualWebBench: How Far Have Multimodal LLMs Evolved in Web Page Understanding and Grounding?}, 
      author={Junpeng Liu and Yifan Song and Bill Yuchen Lin and Wai Lam and Graham Neubig and Yuanzhi Li and Xiang Yue},
      year={2024},
      eprint={2404.05955},
      archivePrefix={arXiv},
      primaryClass={cs.CL}
}
```