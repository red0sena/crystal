---
language:
- en
configs:
- config_name: 0k
  data_files:
  - split: qa1
    path: data/qa1/0k.json
  - split: qa2
    path: data/qa2/0k.json
  - split: qa3
    path: data/qa3/0k.json
  - split: qa4
    path: data/qa4/0k.json
  - split: qa5
    path: data/qa5/0k.json
  - split: qa6
    path: data/qa6/0k.json
  - split: qa7
    path: data/qa7/0k.json
  - split: qa8
    path: data/qa8/0k.json
  - split: qa9
    path: data/qa9/0k.json
  - split: qa10
    path: data/qa10/0k.json
  - split: qa11
    path: data/qa11/0k.json
  - split: qa12
    path: data/qa12/0k.json
  - split: qa13
    path: data/qa13/0k.json
  - split: qa14
    path: data/qa14/0k.json
  - split: qa15
    path: data/qa15/0k.json
  - split: qa16
    path: data/qa16/0k.json
  - split: qa17
    path: data/qa17/0k.json
  - split: qa18
    path: data/qa18/0k.json
  - split: qa19
    path: data/qa19/0k.json
  - split: qa20
    path: data/qa20/0k.json
- config_name: 1k
  data_files:
  - split: qa1
    path: data/qa1/1k.json
  - split: qa2
    path: data/qa2/1k.json
  - split: qa3
    path: data/qa3/1k.json
  - split: qa4
    path: data/qa4/1k.json
  - split: qa5
    path: data/qa5/1k.json
  - split: qa6
    path: data/qa6/1k.json
  - split: qa7
    path: data/qa7/1k.json
  - split: qa8
    path: data/qa8/1k.json
  - split: qa9
    path: data/qa9/1k.json
  - split: qa10
    path: data/qa10/1k.json
- config_name: 2k
  data_files:
  - split: qa1
    path: data/qa1/2k.json
  - split: qa2
    path: data/qa2/2k.json
  - split: qa3
    path: data/qa3/2k.json
  - split: qa4
    path: data/qa4/2k.json
  - split: qa5
    path: data/qa5/2k.json
  - split: qa6
    path: data/qa6/2k.json
  - split: qa7
    path: data/qa7/2k.json
  - split: qa8
    path: data/qa8/2k.json
  - split: qa9
    path: data/qa9/2k.json
  - split: qa10
    path: data/qa10/2k.json
- config_name: 4k
  data_files:
  - split: qa1
    path: data/qa1/4k.json
  - split: qa2
    path: data/qa2/4k.json
  - split: qa3
    path: data/qa3/4k.json
  - split: qa4
    path: data/qa4/4k.json
  - split: qa5
    path: data/qa5/4k.json
  - split: qa6
    path: data/qa6/4k.json
  - split: qa7
    path: data/qa7/4k.json
  - split: qa8
    path: data/qa8/4k.json
  - split: qa9
    path: data/qa9/4k.json
  - split: qa10
    path: data/qa10/4k.json
- config_name: 8k
  data_files:
  - split: qa1
    path: data/qa1/8k.json
  - split: qa2
    path: data/qa2/8k.json
  - split: qa3
    path: data/qa3/8k.json
  - split: qa4
    path: data/qa4/8k.json
  - split: qa5
    path: data/qa5/8k.json
  - split: qa6
    path: data/qa6/8k.json
  - split: qa7
    path: data/qa7/8k.json
  - split: qa8
    path: data/qa8/8k.json
  - split: qa9
    path: data/qa9/8k.json
  - split: qa10
    path: data/qa10/8k.json
- config_name: 16k
  data_files:
  - split: qa1
    path: data/qa1/16k.json
  - split: qa2
    path: data/qa2/16k.json
  - split: qa3
    path: data/qa3/16k.json
  - split: qa4
    path: data/qa4/16k.json
  - split: qa5
    path: data/qa5/16k.json
  - split: qa6
    path: data/qa6/16k.json
  - split: qa7
    path: data/qa7/16k.json
  - split: qa8
    path: data/qa8/16k.json
  - split: qa9
    path: data/qa9/16k.json
  - split: qa10
    path: data/qa10/16k.json
- config_name: 32k
  data_files:
  - split: qa1
    path: data/qa1/32k.json
  - split: qa2
    path: data/qa2/32k.json
  - split: qa3
    path: data/qa3/32k.json
  - split: qa4
    path: data/qa4/32k.json
  - split: qa5
    path: data/qa5/32k.json
  - split: qa6
    path: data/qa6/32k.json
  - split: qa7
    path: data/qa7/32k.json
  - split: qa8
    path: data/qa8/32k.json
  - split: qa9
    path: data/qa9/32k.json
  - split: qa10
    path: data/qa10/32k.json
- config_name: 64k
  data_files:
  - split: qa1
    path: data/qa1/64k.json
  - split: qa2
    path: data/qa2/64k.json
  - split: qa3
    path: data/qa3/64k.json
  - split: qa4
    path: data/qa4/64k.json
  - split: qa5
    path: data/qa5/64k.json
  - split: qa6
    path: data/qa6/64k.json
  - split: qa7
    path: data/qa7/64k.json
  - split: qa8
    path: data/qa8/64k.json
  - split: qa9
    path: data/qa9/64k.json
  - split: qa10
    path: data/qa10/64k.json
- config_name: 128k
  data_files:
  - split: qa1
    path: data/qa1/128k.json
  - split: qa2
    path: data/qa2/128k.json
  - split: qa3
    path: data/qa3/128k.json
  - split: qa4
    path: data/qa4/128k.json
  - split: qa5
    path: data/qa5/128k.json
  - split: qa6
    path: data/qa6/128k.json
  - split: qa7
    path: data/qa7/128k.json
  - split: qa8
    path: data/qa8/128k.json
  - split: qa9
    path: data/qa9/128k.json
  - split: qa10
    path: data/qa10/128k.json
- config_name: 256k
  data_files:
  - split: qa1
    path: data/qa1/256k.json
  - split: qa2
    path: data/qa2/256k.json
  - split: qa3
    path: data/qa3/256k.json
  - split: qa4
    path: data/qa4/256k.json
  - split: qa5
    path: data/qa5/256k.json
  - split: qa6
    path: data/qa6/256k.json
  - split: qa7
    path: data/qa7/256k.json
  - split: qa8
    path: data/qa8/256k.json
  - split: qa9
    path: data/qa9/256k.json
  - split: qa10
    path: data/qa10/256k.json
- config_name: 512k
  data_files:
  - split: qa1
    path: data/qa1/512k.json
  - split: qa2
    path: data/qa2/512k.json
  - split: qa3
    path: data/qa3/512k.json
  - split: qa4
    path: data/qa4/512k.json
  - split: qa5
    path: data/qa5/512k.json
  - split: qa6
    path: data/qa6/512k.json
  - split: qa7
    path: data/qa7/512k.json
  - split: qa8
    path: data/qa8/512k.json
  - split: qa9
    path: data/qa9/512k.json
  - split: qa10
    path: data/qa10/512k.json
- config_name: 1M
  data_files:
  - split: qa1
    path: data/qa1/1M.json
  - split: qa2
    path: data/qa2/1M.json
  - split: qa3
    path: data/qa3/1M.json
  - split: qa4
    path: data/qa4/1M.json
  - split: qa5
    path: data/qa5/1M.json
  - split: qa6
    path: data/qa6/1M.json
  - split: qa7
    path: data/qa7/1M.json
  - split: qa8
    path: data/qa8/1M.json
  - split: qa9
    path: data/qa9/1M.json
  - split: qa10
    path: data/qa10/1M.json
- config_name: 10M
  data_files:
  - split: qa1
    path: data/qa1/10M.json
  - split: qa2
    path: data/qa2/10M.json
  - split: qa3
    path: data/qa3/10M.json
  - split: qa4
    path: data/qa4/10M.json
  - split: qa5
    path: data/qa5/10M.json
- config_name: qa1
  data_files:
  - split: 0k
    path: data/qa1/0k.json
  - split: 1k
    path: data/qa1/1k.json
  - split: 2k
    path: data/qa1/2k.json
  - split: 4k
    path: data/qa1/4k.json
  - split: 8k
    path: data/qa1/8k.json
  - split: 16k
    path: data/qa1/16k.json
  - split: 32k
    path: data/qa1/32k.json
  - split: 64k
    path: data/qa1/64k.json
  - split: 128k
    path: data/qa1/128k.json
  - split: 256k
    path: data/qa1/256k.json
  - split: 512k
    path: data/qa1/512k.json
  - split: 1M
    path: data/qa1/1M.json
- config_name: qa2
  data_files:
  - split: 0k
    path: data/qa2/0k.json
  - split: 1k
    path: data/qa2/1k.json
  - split: 2k
    path: data/qa2/2k.json
  - split: 4k
    path: data/qa2/4k.json
  - split: 8k
    path: data/qa2/8k.json
  - split: 16k
    path: data/qa2/16k.json
  - split: 32k
    path: data/qa2/32k.json
  - split: 64k
    path: data/qa2/64k.json
  - split: 128k
    path: data/qa2/128k.json
  - split: 256k
    path: data/qa2/256k.json
  - split: 512k
    path: data/qa2/512k.json
  - split: 1M
    path: data/qa2/1M.json
- config_name: qa3
  data_files:
  - split: 0k
    path: data/qa3/0k.json
  - split: 1k
    path: data/qa3/1k.json
  - split: 2k
    path: data/qa3/2k.json
  - split: 4k
    path: data/qa3/4k.json
  - split: 8k
    path: data/qa3/8k.json
  - split: 16k
    path: data/qa3/16k.json
  - split: 32k
    path: data/qa3/32k.json
  - split: 64k
    path: data/qa3/64k.json
  - split: 128k
    path: data/qa3/128k.json
  - split: 256k
    path: data/qa3/256k.json
  - split: 512k
    path: data/qa3/512k.json
  - split: 1M
    path: data/qa3/1M.json
- config_name: qa4
  data_files:
  - split: 0k
    path: data/qa4/0k.json
  - split: 1k
    path: data/qa4/1k.json
  - split: 2k
    path: data/qa4/2k.json
  - split: 4k
    path: data/qa4/4k.json
  - split: 8k
    path: data/qa4/8k.json
  - split: 16k
    path: data/qa4/16k.json
  - split: 32k
    path: data/qa4/32k.json
  - split: 64k
    path: data/qa4/64k.json
  - split: 128k
    path: data/qa4/128k.json
  - split: 256k
    path: data/qa4/256k.json
  - split: 512k
    path: data/qa4/512k.json
  - split: 1M
    path: data/qa4/1M.json
- config_name: qa5
  data_files:
  - split: 0k
    path: data/qa5/0k.json
  - split: 1k
    path: data/qa5/1k.json
  - split: 2k
    path: data/qa5/2k.json
  - split: 4k
    path: data/qa5/4k.json
  - split: 8k
    path: data/qa5/8k.json
  - split: 16k
    path: data/qa5/16k.json
  - split: 32k
    path: data/qa5/32k.json
  - split: 64k
    path: data/qa5/64k.json
  - split: 128k
    path: data/qa5/128k.json
  - split: 256k
    path: data/qa5/256k.json
  - split: 512k
    path: data/qa5/512k.json
  - split: 1M
    path: data/qa5/1M.json
- config_name: qa6
  data_files:
  - split: 0k
    path: data/qa6/0k.json
  - split: 1k
    path: data/qa6/1k.json
  - split: 2k
    path: data/qa6/2k.json
  - split: 4k
    path: data/qa6/4k.json
  - split: 8k
    path: data/qa6/8k.json
  - split: 16k
    path: data/qa6/16k.json
  - split: 32k
    path: data/qa6/32k.json
  - split: 64k
    path: data/qa6/64k.json
  - split: 128k
    path: data/qa6/128k.json
  - split: 256k
    path: data/qa6/256k.json
  - split: 512k
    path: data/qa6/512k.json
  - split: 1M
    path: data/qa6/1M.json
- config_name: qa7
  data_files:
  - split: 0k
    path: data/qa7/0k.json
  - split: 1k
    path: data/qa7/1k.json
  - split: 2k
    path: data/qa7/2k.json
  - split: 4k
    path: data/qa7/4k.json
  - split: 8k
    path: data/qa7/8k.json
  - split: 16k
    path: data/qa7/16k.json
  - split: 32k
    path: data/qa7/32k.json
  - split: 64k
    path: data/qa7/64k.json
  - split: 128k
    path: data/qa7/128k.json
  - split: 256k
    path: data/qa7/256k.json
  - split: 512k
    path: data/qa7/512k.json
  - split: 1M
    path: data/qa7/1M.json
- config_name: qa8
  data_files:
  - split: 0k
    path: data/qa8/0k.json
  - split: 1k
    path: data/qa8/1k.json
  - split: 2k
    path: data/qa8/2k.json
  - split: 4k
    path: data/qa8/4k.json
  - split: 8k
    path: data/qa8/8k.json
  - split: 16k
    path: data/qa8/16k.json
  - split: 32k
    path: data/qa8/32k.json
  - split: 64k
    path: data/qa8/64k.json
  - split: 128k
    path: data/qa8/128k.json
  - split: 256k
    path: data/qa8/256k.json
  - split: 512k
    path: data/qa8/512k.json
  - split: 1M
    path: data/qa8/1M.json
- config_name: qa9
  data_files:
  - split: 0k
    path: data/qa9/0k.json
  - split: 1k
    path: data/qa9/1k.json
  - split: 2k
    path: data/qa9/2k.json
  - split: 4k
    path: data/qa9/4k.json
  - split: 8k
    path: data/qa9/8k.json
  - split: 16k
    path: data/qa9/16k.json
  - split: 32k
    path: data/qa9/32k.json
  - split: 64k
    path: data/qa9/64k.json
  - split: 128k
    path: data/qa9/128k.json
  - split: 256k
    path: data/qa9/256k.json
  - split: 512k
    path: data/qa9/512k.json
  - split: 1M
    path: data/qa9/1M.json
- config_name: qa10
  data_files:
  - split: 0k
    path: data/qa10/0k.json
  - split: 1k
    path: data/qa10/1k.json
  - split: 2k
    path: data/qa10/2k.json
  - split: 4k
    path: data/qa10/4k.json
  - split: 8k
    path: data/qa10/8k.json
  - split: 16k
    path: data/qa10/16k.json
  - split: 32k
    path: data/qa10/32k.json
  - split: 64k
    path: data/qa10/64k.json
  - split: 128k
    path: data/qa10/128k.json
  - split: 256k
    path: data/qa10/256k.json
  - split: 512k
    path: data/qa10/512k.json
  - split: 1M
    path: data/qa10/1M.json
---

# BABILong (100 samples) : a long-context needle-in-a-haystack benchmark for LLMs

Preprint is on [arXiv](https://arxiv.org/abs/2406.10149) and code for LLM evaluation is available on [GitHub](https://github.com/booydar/babilong).

[BABILong Leaderboard](https://huggingface.co/spaces/RMT-team/babilong) with top-performing long-context models.

## bAbI + Books = BABILong

**BABILong** is a novel generative benchmark for evaluating the performance of NLP models in
processing arbitrarily long documents with distributed facts.

It contains 11 configs, corresponding to different sequence lengths in tokens: 0k, 1k, 2k, 4k, 8k, 16k, 32k, 128k, 256k, 512k, 1M. 

```
from datasets import load_dataset
babilong = load_dataset("RMT-team/babilong", "128k")["qa1"]
```

Solving tasks with a long context size requires the model to distinguish important information from large amounts of irrelevant details. To simulate this behavior we ”hide” the sentences of the original task between the sentences of irrelevant text. We use the [bAbI](https://huggingface.co/datasets/facebook/babi_qa) dataset [1] as facts and [PG19](https://huggingface.co/datasets/pg19) as background text. Resulting test samples might have lenghts of **millions of tokens**.

BABILong consists of 10 tasks designed for evaluation of basic aspects of reasoning. The bAbI tasks are generated by simulating a set of characters and objects engaged in various movements and interactions with each other in multiple locations. Each interaction is represented by a fact, e.g. **”Mary travelled to the office”**, and the task is to answer a question using the facts from the current simulation, for instance, **”Where is Mary?”**. The bAbI tasks vary based on the number of facts, question complexity and the aspects of reasoning.

### First ten tasks of BABILong

 | Task | Name                     | facts per task | supporting facts per task |
|------|--------------------------|-----------------|---------------------------|
| qa1  | single supporting fact   | 2 - 10          | 1                         |
| qa2  | two supporting facts     | 2 - 68          | 2                         |
| qa3  | three supporting facts   | 4 - 32          | 3                         |
| qa4  | two arg relations        | 2               | 1                         |
| qa5  | three arg relations      | 2 - 126         | 1                         |
| qa6  | yes-no questions         | 2 - 26          | 1                         |
| qa7  | counting                 | 2 - 52          | 1-10                      |
| qa8  | lists-sets               | 2 - 50          | 1-8                       |
| qa9  | simple negation          | 2 - 10          | 1                         |
| qa10 | indefinite knowledge     | 2 - 10          | 1                         |

Join us in this exciting endeavor and let's push the boundaries of what's possible together!

## Citation
```
@misc{kuratov2024babilong,
      title={BABILong: Testing the Limits of LLMs with Long Context Reasoning-in-a-Haystack}, 
      author={Yuri Kuratov and Aydar Bulatov and Petr Anokhin and Ivan Rodkin and Dmitry Sorokin and Artyom Sorokin and Mikhail Burtsev},
      year={2024},
      eprint={2406.10149},
      archivePrefix={arXiv},
      primaryClass={id='cs.CL' full_name='Computation and Language' is_active=True alt_name='cmp-lg' in_archive='cs' is_general=False description='Covers natural language processing. Roughly includes material in ACM Subject Class I.2.7. Note that work on artificial languages (programming languages, logics, formal systems) that does not explicitly address natural-language issues broadly construed (natural-language processing, computational linguistics, speech, text retrieval, etc.) is not appropriate for this area.'}
}
```

```
@misc{kuratov2024search,
      title={In Search of Needles in a 10M Haystack: Recurrent Memory Finds What LLMs Miss}, 
      author={Yuri Kuratov and Aydar Bulatov and Petr Anokhin and Dmitry Sorokin and Artyom Sorokin and Mikhail Burtsev},
      year={2024},
      eprint={2402.10790},
      archivePrefix={arXiv},
      primaryClass={cs.CL}
}
```

## References

[1] Weston, Jason, et al. "Towards ai-complete question answering: A set of prerequisite toy tasks." arXiv preprint [arXiv:1502.05698](https://arxiv.org/abs/1502.05698) (2015).

## License

Our code is released under the Apache 2.0 License. We use data from the PG-19 corpora (Rae et al., 2020) ([Apache 2.0 License](https://github.com/google-deepmind/pg19/blob/master/LICENSE)) and the bAbI dataset (Weston et al., 2016) ([BSD License](https://github.com/facebookarchive/bAbI-tasks/blob/master/LICENSE.md)).