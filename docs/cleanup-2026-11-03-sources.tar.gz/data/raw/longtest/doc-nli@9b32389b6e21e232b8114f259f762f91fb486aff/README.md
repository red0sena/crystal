---
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: validation
    path: data/validation-*
  - split: test
    path: data/test-*
dataset_info:
  features:
  - name: premise
    dtype: string
  - name: label
    dtype: string
  - name: hypothesis
    dtype: string
  splits:
  - name: train
    num_bytes: 1758995420.312401
    num_examples: 861708
  - name: validation
    num_bytes: 553908139.6429919
    num_examples: 210683
  - name: test
    num_bytes: 637709787.6263076
    num_examples: 243460
  download_size: 401416382
  dataset_size: 2950613347.5817003
license: bsd
task_categories:
- text-classification
language:
- en
tags:
- natural-language-inference
---
# Dataset Card for "doc-nli"

https://github.com/salesforce/DocNLI/tree/main

```
@inproceedings{yin-etal-2021-docnli,
    title = "{D}oc{NLI}: A Large-scale Dataset for Document-level Natural Language Inference",
    author = "Yin, Wenpeng  and
      Radev, Dragomir  and
      Xiong, Caiming",
    editor = "Zong, Chengqing  and
      Xia, Fei  and
      Li, Wenjie  and
      Navigli, Roberto",
    booktitle = "Findings of the Association for Computational Linguistics: ACL-IJCNLP 2021",
    month = aug,
    year = "2021",
    address = "Online",
    publisher = "Association for Computational Linguistics",
    url = "https://aclanthology.org/2021.findings-acl.435",
    doi = "10.18653/v1/2021.findings-acl.435",
    pages = "4913--4922",
}
```