---
license: mit
dataset_info:
- config_name: challenge_all_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: challenge
    num_bytes: 261636425.25
    num_examples: 1590
  download_size: 261271928
  dataset_size: 261636425.25
- config_name: challenge_all_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: isBalanced
    dtype: bool
  splits:
  - name: challenge
    num_bytes: 50797705
    num_examples: 713449
  download_size: 19869828
  dataset_size: 50797705
- config_name: challenge_balanced_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: challenge
    num_bytes: 261636425.25
    num_examples: 1590
  download_size: 261333538
  dataset_size: 261636425.25
- config_name: challenge_balanced_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: isBalanced
    dtype: bool
  splits:
  - name: challenge
    num_bytes: 3523973
    num_examples: 50726
  download_size: 1787024
  dataset_size: 3523973
- config_name: submission_all_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: submission
    num_bytes: 2314978438.875
    num_examples: 15545
  download_size: 2309217874
  dataset_size: 2314978438.875
- config_name: submission_all_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: isBalanced
    dtype: bool
  splits:
  - name: submission
    num_bytes: 298875520
    num_examples: 4237524
  download_size: 121458425
  dataset_size: 298875520
- config_name: test_all_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: test
    num_bytes: 492571840.875
    num_examples: 2993
  download_size: 491611526
  dataset_size: 492571840.875
- config_name: test_all_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: isBalanced
    dtype: bool
  splits:
  - name: test
    num_bytes: 95588974
    num_examples: 1340048
  download_size: 39561711
  dataset_size: 95588974
- config_name: test_balanced_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: test
    num_bytes: 491210370.625
    num_examples: 2987
  download_size: 490293506
  dataset_size: 491210370.625
- config_name: test_balanced_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: isBalanced
    dtype: bool
  splits:
  - name: test
    num_bytes: 6622775
    num_examples: 95336
  download_size: 3401070
  dataset_size: 6622775
- config_name: testdev_all_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: testdev
    num_bytes: 65779269.0
    num_examples: 398
  download_size: 65670255
  dataset_size: 65779269.0
- config_name: testdev_all_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: answer
    dtype: string
  - name: fullAnswer
    dtype: string
  - name: isBalanced
    dtype: bool
  - name: groups
    struct:
    - name: global
      dtype: string
    - name: local
      dtype: string
  - name: entailed
    dtype: string
  - name: equivalent
    dtype: string
  - name: types
    struct:
    - name: structural
      dtype: string
    - name: semantic
      dtype: string
    - name: detailed
      dtype: string
  - name: annotations
    sequence:
    - name: question
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: answer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: fullAnswer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
  - name: semantic
    list:
    - name: operation
      dtype: string
    - name: argument
      dtype: string
    - name: dependencies
      sequence: int32
  - name: semanticStr
    dtype: string
  splits:
  - name: testdev
    num_bytes: 86970760
    num_examples: 172174
  download_size: 23385535
  dataset_size: 86970760
- config_name: testdev_balanced_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: testdev
    num_bytes: 65779269.0
    num_examples: 398
  download_size: 65647745
  dataset_size: 65779269.0
- config_name: testdev_balanced_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: answer
    dtype: string
  - name: fullAnswer
    dtype: string
  - name: isBalanced
    dtype: bool
  - name: groups
    struct:
    - name: global
      dtype: string
    - name: local
      dtype: string
  - name: entailed
    dtype: string
  - name: equivalent
    dtype: string
  - name: types
    struct:
    - name: structural
      dtype: string
    - name: semantic
      dtype: string
    - name: detailed
      dtype: string
  - name: annotations
    sequence:
    - name: question
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: answer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: fullAnswer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
  - name: semantic
    list:
    - name: operation
      dtype: string
    - name: argument
      dtype: string
    - name: dependencies
      sequence: int32
  - name: semanticStr
    dtype: string
  splits:
  - name: testdev
    num_bytes: 6113469
    num_examples: 12578
  download_size: 2090335
  dataset_size: 6113469
- config_name: train_all_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: train
    num_bytes: 10509758457.0
    num_examples: 74256
  download_size: 10480239090
  dataset_size: 10509758457.0
- config_name: train_all_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: answer
    dtype: string
  - name: fullAnswer
    dtype: string
  - name: isBalanced
    dtype: bool
  - name: groups
    struct:
    - name: global
      dtype: string
    - name: local
      dtype: string
  - name: entailed
    dtype: string
  - name: equivalent
    dtype: string
  - name: types
    struct:
    - name: structural
      dtype: string
    - name: semantic
      dtype: string
    - name: detailed
      dtype: string
  - name: annotations
    sequence:
    - name: question
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: answer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: fullAnswer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
  - name: semantic
    list:
    - name: operation
      dtype: string
    - name: argument
      dtype: string
    - name: dependencies
      sequence: int32
  - name: semanticStr
    dtype: string
  splits:
  - name: train
    num_bytes: 6891129609
    num_examples: 14305356
  download_size: 1874173198
  dataset_size: 6891129609
- config_name: train_balanced_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: train
    num_bytes: 10200292415.5
    num_examples: 72140
  download_size: 10171627271
  dataset_size: 10200292415.5
- config_name: train_balanced_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: answer
    dtype: string
  - name: fullAnswer
    dtype: string
  - name: isBalanced
    dtype: bool
  - name: groups
    struct:
    - name: global
      dtype: string
    - name: local
      dtype: string
  - name: entailed
    dtype: string
  - name: equivalent
    dtype: string
  - name: types
    struct:
    - name: structural
      dtype: string
    - name: semantic
      dtype: string
    - name: detailed
      dtype: string
  - name: annotations
    sequence:
    - name: question
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: answer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: fullAnswer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
  - name: semantic
    list:
    - name: operation
      dtype: string
    - name: argument
      dtype: string
    - name: dependencies
      sequence: int32
  - name: semanticStr
    dtype: string
  splits:
  - name: train
    num_bytes: 460429581
    num_examples: 943000
  download_size: 183979778
  dataset_size: 460429581
- config_name: val_all_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: val
    num_bytes: 1494990904.5
    num_examples: 10564
  download_size: 1490744689
  dataset_size: 1494990904.5
- config_name: val_all_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: answer
    dtype: string
  - name: fullAnswer
    dtype: string
  - name: isBalanced
    dtype: bool
  - name: groups
    struct:
    - name: global
      dtype: string
    - name: local
      dtype: string
  - name: entailed
    dtype: string
  - name: equivalent
    dtype: string
  - name: types
    struct:
    - name: structural
      dtype: string
    - name: semantic
      dtype: string
    - name: detailed
      dtype: string
  - name: annotations
    sequence:
    - name: question
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: answer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: fullAnswer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
  - name: semantic
    list:
    - name: operation
      dtype: string
    - name: argument
      dtype: string
    - name: dependencies
      sequence: int32
  - name: semanticStr
    dtype: string
  splits:
  - name: val
    num_bytes: 967338322
    num_examples: 2011853
  download_size: 266476025
  dataset_size: 967338322
- config_name: val_balanced_images
  features:
  - name: id
    dtype: string
  - name: image
    dtype: image
  splits:
  - name: val
    num_bytes: 1447074448.75
    num_examples: 10234
  download_size: 1443033919
  dataset_size: 1447074448.75
- config_name: val_balanced_instructions
  features:
  - name: id
    dtype: string
  - name: imageId
    dtype: string
  - name: question
    dtype: string
  - name: answer
    dtype: string
  - name: fullAnswer
    dtype: string
  - name: isBalanced
    dtype: bool
  - name: groups
    struct:
    - name: global
      dtype: string
    - name: local
      dtype: string
  - name: entailed
    dtype: string
  - name: equivalent
    dtype: string
  - name: types
    struct:
    - name: structural
      dtype: string
    - name: semantic
      dtype: string
    - name: detailed
      dtype: string
  - name: annotations
    sequence:
    - name: question
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: answer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
    - name: fullAnswer
      struct:
      - name: objectId
        dtype: string
      - name: value
        dtype: string
  - name: semantic
    list:
    - name: operation
      dtype: string
    - name: argument
      dtype: string
    - name: dependencies
      sequence: int32
  - name: semanticStr
    dtype: string
  splits:
  - name: val
    num_bytes: 64498952
    num_examples: 132062
  download_size: 25794272
  dataset_size: 64498952
configs:
- config_name: challenge_all_images
  data_files:
  - split: challenge
    path: challenge_all_images/challenge-*
- config_name: challenge_all_instructions
  data_files:
  - split: challenge
    path: challenge_all_instructions/challenge-*
- config_name: challenge_balanced_images
  data_files:
  - split: challenge
    path: challenge_balanced_images/challenge-*
- config_name: challenge_balanced_instructions
  data_files:
  - split: challenge
    path: challenge_balanced_instructions/challenge-*
- config_name: submission_all_images
  data_files:
  - split: submission
    path: submission_all_images/submission-*
- config_name: submission_all_instructions
  data_files:
  - split: submission
    path: submission_all_instructions/submission-*
- config_name: test_all_images
  data_files:
  - split: test
    path: test_all_images/test-*
- config_name: test_all_instructions
  data_files:
  - split: test
    path: test_all_instructions/test-*
- config_name: test_balanced_images
  data_files:
  - split: test
    path: test_balanced_images/test-*
- config_name: test_balanced_instructions
  data_files:
  - split: test
    path: test_balanced_instructions/test-*
- config_name: testdev_all_images
  data_files:
  - split: testdev
    path: testdev_all_images/testdev-*
- config_name: testdev_all_instructions
  data_files:
  - split: testdev
    path: testdev_all_instructions/testdev-*
- config_name: testdev_balanced_images
  data_files:
  - split: testdev
    path: testdev_balanced_images/testdev-*
- config_name: testdev_balanced_instructions
  data_files:
  - split: testdev
    path: testdev_balanced_instructions/testdev-*
- config_name: train_all_images
  data_files:
  - split: train
    path: train_all_images/train-*
- config_name: train_all_instructions
  data_files:
  - split: train
    path: train_all_instructions/train-*
- config_name: train_balanced_images
  data_files:
  - split: train
    path: train_balanced_images/train-*
- config_name: train_balanced_instructions
  data_files:
  - split: train
    path: train_balanced_instructions/train-*
- config_name: val_all_images
  data_files:
  - split: val
    path: val_all_images/val-*
- config_name: val_all_instructions
  data_files:
  - split: val
    path: val_all_instructions/val-*
- config_name: val_balanced_images
  data_files:
  - split: val
    path: val_balanced_images/val-*
- config_name: val_balanced_instructions
  data_files:
  - split: val
    path: val_balanced_instructions/val-*
---

<p align="center" width="100%">
<img src="https://i.postimg.cc/g0QRgMVv/WX20240228-113337-2x.png"  width="100%" height="80%">
</p>

# Large-scale Multi-modality Models Evaluation Suite

> Accelerating the development of large-scale multi-modality models (LMMs) with `lmms-eval`

🏠 [Homepage](https://lmms-lab.github.io/) | 📚 [Documentation](docs/README.md) | 🤗 [Huggingface Datasets](https://huggingface.co/lmms-lab)

# This Dataset

This is a formatted version of [GQA](hhttps://cs.stanford.edu/people/dorarad/gqa/about.html). It is used in our `lmms-eval` pipeline to allow for one-click evaluations of large multi-modality models.

```
@inproceedings{hudson2019gqa,
  title={Gqa: A new dataset for real-world visual reasoning and compositional question answering},
  author={Hudson, Drew A and Manning, Christopher D},
  booktitle={Proceedings of the IEEE/CVF conference on computer vision and pattern recognition},
  pages={6700--6709},
  year={2019}
}
```