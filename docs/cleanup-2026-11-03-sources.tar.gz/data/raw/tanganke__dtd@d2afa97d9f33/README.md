---
dataset_info:
  features:
  - name: image
    dtype: image
  - name: label
    dtype:
      class_label:
        names:
          '0': banded
          '1': blotchy
          '2': braided
          '3': bubbly
          '4': bumpy
          '5': chequered
          '6': cobwebbed
          '7': cracked
          '8': crosshatched
          '9': crystalline
          '10': dotted
          '11': fibrous
          '12': flecked
          '13': freckled
          '14': frilly
          '15': gauzy
          '16': grid
          '17': grooved
          '18': honeycombed
          '19': interlaced
          '20': knitted
          '21': lacelike
          '22': lined
          '23': marbled
          '24': matted
          '25': meshed
          '26': paisley
          '27': perforated
          '28': pitted
          '29': pleated
          '30': polka-dotted
          '31': porous
          '32': potholed
          '33': scaly
          '34': smeared
          '35': spiralled
          '36': sprinkled
          '37': stained
          '38': stratified
          '39': striped
          '40': studded
          '41': swirly
          '42': veined
          '43': waffled
          '44': woven
          '45': wrinkled
          '46': zigzagged
  splits:
  - name: train
    num_bytes: 463693721.28
    num_examples: 3760
  - name: test
    num_bytes: 171623828.0
    num_examples: 1880
  download_size: 629499529
  dataset_size: 635317549.28
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: test
    path: data/test-*
---

# [DTD: Describable Textures Dataset](https://www.robots.ox.ac.uk/~vgg/data/dtd/)

The Describable Textures Dataset (DTD) is an evolving collection of textural images in the wild, annotated with a series of human-centric attributes, inspired by the perceptual properties of textures. 
This data is made available to the computer vision community for research purposes

## Usage

```python
from datasets import load_dataset

dataset = load_dataset('tanganke/dtd')
```

- **Features:**
  - **Image**: The primary data type, which is a digital image used for classification. The format and dimensions of the images are not specified in this snippet but should be included if available.
  - **Label**: A categorical feature representing the texture or pattern class of each image. The dataset includes 46 classes with descriptive names ranging from 'banded' to 'zigzagged'.
    - **Class Labels**:
      - '0': banded
      - '1': blotchy
      - '2': braided
      - ...
      - '45': wrinkled
      - '46': zigzagged

- **Splits**: The dataset is divided into training and test subsets for model evaluation.
  - **Training**: containing 3760 examples with a total size of 448,550 bytes.
  - **Test**: containing 1880 examples with a total size of 220,515 bytes.

