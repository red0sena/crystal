---
language:
- en
size_categories:
- 10K<n<100K
task_categories:
- image-classification
dataset_info:
  features:
  - name: image
    dtype: image
  - name: label
    dtype:
      class_label:
        names:
          '0': annual crop land
          '1': forest
          '2': brushland or shrubland
          '3': highway or road
          '4': industrial buildings or commercial buildings
          '5': pasture land
          '6': permanent crop land
          '7': residential buildings or homes or apartments
          '8': river
          '9': lake or sea
  splits:
  - name: train
    num_bytes: 70654720.8
    num_examples: 21600
  - name: test
    num_bytes: 8626053.5
    num_examples: 2700
  - name: contrast
    num_bytes: 2577694.4
    num_examples: 2700
  - name: gaussian_noise
    num_bytes: 4344552.8
    num_examples: 2700
  - name: impulse_noise
    num_bytes: 4551961.4
    num_examples: 2700
  - name: jpeg_compression
    num_bytes: 2879624.6
    num_examples: 2700
  - name: motion_blur
    num_bytes: 2881150.1
    num_examples: 2700
  - name: pixelate
    num_bytes: 2114682.2
    num_examples: 2700
  - name: spatter
    num_bytes: 4174215.2
    num_examples: 2700
  download_size: 98645265
  dataset_size: 102804655.0
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: test
    path: data/test-*
  - split: contrast
    path: data/contrast-*
  - split: gaussian_noise
    path: data/gaussian_noise-*
  - split: impulse_noise
    path: data/impulse_noise-*
  - split: jpeg_compression
    path: data/jpeg_compression-*
  - split: motion_blur
    path: data/motion_blur-*
  - split: pixelate
    path: data/pixelate-*
  - split: spatter
    path: data/spatter-*
---


# Dataset Card for EuroSAT

# Dataset Source

- [Paper with code](https://paperswithcode.com/dataset/eurosat)


# Usage

```python
from datasets import load_dataset

dataset = load_dataset('tranganke/eurosat')
```


### Data Fields

The dataset contains the following fields:

- `image`: An image in RGB format.
- `label`: The label for the image, which is one of 10 classes:
  - 0: annual crop land 
  - 1: forest
  - 2: brushland or shrubland
  - 3: highway or road
  - 4: industrial buildings or commercial buildings
  - 5: pasture land
  - 6: permanent crop land
  - 7: residential buildings or homes or apartments
  - 8: river
  - 9: lake or sea

### Data Splits

The dataset contains the following splits:

- `train`: 21,600 examples
- `test`: 2,700 examples
- `contrast`: 2,700 examples
- `gaussian_noise`: 2,700 example
- `impulse_noise`: 2,700 examples
- `jpeg_compression`: 2,700 examples
- `motion_blur`: 2,700 examples
- `pixelate`: 2,700 examples
- `spatter`: 2,700 examples

You can use any of the provided BibTeX entries for your reference list:

```bibtex
@article{helber2019eurosat,
  title={Eurosat: A novel dataset and deep learning benchmark for land use and land cover classification},
  author={Helber, Patrick and Bischke, Benjamin and Dengel, Andreas and Borth, Damian},
  journal={IEEE Journal of Selected Topics in Applied Earth Observations and Remote Sensing},
  volume={12},
  number={7},
  pages={2217--2226},
  year={2019},
  publisher={IEEE}
}

@misc{yangAdaMergingAdaptiveModel2023,
  title = {{{AdaMerging}}: {{Adaptive Model Merging}} for {{Multi-Task Learning}}},
  shorttitle = {{{AdaMerging}}},
  author = {Yang, Enneng and Wang, Zhenyi and Shen, Li and Liu, Shiwei and Guo, Guibing and Wang, Xingwei and Tao, Dacheng},
  year = {2023},
  month = oct,
  number = {arXiv:2310.02575},
  eprint = {2310.02575},
  primaryclass = {cs},
  publisher = {arXiv},
  doi = {10.48550/arXiv.2310.02575},
  url = {http://arxiv.org/abs/2310.02575},
  archiveprefix = {arxiv},
  keywords = {Computer Science - Computer Vision and Pattern Recognition,Computer Science - Machine Learning}
}

@misc{tangConcreteSubspaceLearning2023,
  title = {Concrete {{Subspace Learning}} Based {{Interference Elimination}} for {{Multi-task Model Fusion}}},
  author = {Tang, Anke and Shen, Li and Luo, Yong and Ding, Liang and Hu, Han and Du, Bo and Tao, Dacheng},
  year = {2023},
  month = dec,
  number = {arXiv:2312.06173},
  eprint = {2312.06173},
  publisher = {arXiv},
  url = {http://arxiv.org/abs/2312.06173},
  archiveprefix = {arxiv},
  copyright = {All rights reserved},
  keywords = {Computer Science - Machine Learning}
}


@misc{tangMergingMultiTaskModels2024,
  title = {Merging {{Multi-Task Models}} via {{Weight-Ensembling Mixture}} of {{Experts}}},
  author = {Tang, Anke and Shen, Li and Luo, Yong and Yin, Nan and Zhang, Lefei and Tao, Dacheng},
  year = {2024},
  month = feb,
  number = {arXiv:2402.00433},
  eprint = {2402.00433},
  primaryclass = {cs},
  publisher = {arXiv},
  doi = {10.48550/arXiv.2402.00433},
  url = {http://arxiv.org/abs/2402.00433},
  archiveprefix = {arxiv},
  copyright = {All rights reserved},
  keywords = {Computer Science - Computer Vision and Pattern Recognition,Computer Science - Machine Learning}
}
```