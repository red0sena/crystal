---
license: apache-2.0
dataset_info:
  features:
  - name: Index
    dtype: int64
  - name: Image_0
    dtype: image
  - name: Image_1
    dtype: image
  - name: Question_0
    dtype: string
  - name: Image_0_Question_0
    dtype: string
  - name: Image_1_Question_0
    dtype: string
  - name: Question_1
    dtype: string
  - name: Image_0_Question_1
    dtype: string
  - name: Image_1_Question_1
    dtype: string
  - name: Question_Type
    dtype: string
  - name: Source
    dtype: string
  splits:
  - name: train
    num_bytes: 1152300040.1
    num_examples: 1900
  download_size: 1141602282
  dataset_size: 1152300040.1
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
---
<!-- # <span style="color:red">NaturalBench Benchmark</span> (Neurips24) -->

# ***<span style="color:red">(NeurIPS24)</span> NaturalBench: Evaluating Vision-Language Models on Natural Adversarial Samples***
---
<div align="center">
Baiqi Li<sup>1*</sup>, Zhiqiu Lin<sup>1*</sup>, Wenxuan Peng<sup>1*</sup>, Jean de Dieu Nyandwi<sup>1*</sup>, Daniel Jiang<sup>1</sup>, Zixian Ma<sup>2</sup>, Simran Khanuja<sup>1</sup>, Ranjay Krishna<sup>2†</sup>, Graham Neubig<sup>1†</sup>,  Deva Ramanan<sup>1†</sup>.
</div>

<div align="center" style="font-weight:bold;">
<sup>1</sup>Carnegie Mellon University, <sup>2</sup>University of Washington
</div>
</div>

<div align="center">
  <img src="https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/natural_teaser.jpg" style="width: 80%; height: auto;">
</div>
<!-- ![](https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/natural_teaser.jpg) -->



## Links:

<div align="center">

| [🏠**Home Page**](https://linzhiqiu.github.io/papers/naturalbench) | [&#129303;**HuggingFace**](https://huggingface.co/datasets/BaiqiL/NaturalBench) | [**🏆Leaderboard**](#Leaderboard) | [**📖Paper**](https://arxiv.org/pdf/2410.14669) | [🖥️ **Code**](https://github.com/Baiqi-Li/NaturalBench/blob/main/example.py)

</div>

## Citation Information

```
@article{li2024naturalbench,
  title={Naturalbench: Evaluating vision-language models on natural adversarial samples},
  author={Li, Baiqi and Lin, Zhiqiu and Peng, Wenxuan and Nyandwi, Jean de Dieu and Jiang, Daniel and Ma, Zixian and Khanuja, Simran and Krishna, Ranjay and Neubig, Graham and Ramanan, Deva},
  journal={Advances in Neural Information Processing Systems},
  volume={37},
  pages={17044--17068},
  year={2024}
}
```

## Description:

**NaturalBench benchmark:** Vision-language models (VLMs) have made significant progress in recent visual-question-answering (VQA) benchmarks that evaluate complex visio-linguistic reasoning. However, are these models truly effective? In this work, we show that VLMs still struggle with natural images and questions that humans can easily answer, which we term **natural adversarial samples**. We also find it surprisingly easy to generate these VQA samples from natural image-text corpora using off-the-shelf models like CLIP and ChatGPT. We propose a semi-automated approach to collect a new benchmark, **NaturalBench**, for reliably evaluating VLMs with over 10,000 human-verified VQA samples. _Crucially, we adopt a **vision-centric** design by pairing each question with two images that yield different answers, preventing "blind" solutions from answering without using the images._ This makes NaturalBench more challenging than previous benchmarks that can largely be solved with language priors like commonsense knowledge.

### Languages

English, Chinese, Hindi

### Supported Tasks

VQA; Evaluation for VLMs.

### Usage

```python
# load the NaturalBench benchmark
from datasets import load_dataset

dataset = load_dataset("BaiqiL/NaturalBench")

#Usage and Evaluation codes in https://github.com/Baiqi-Li/NaturalBench/blob/main/example.py
```

## Dataset Structure

### Data Instances

```
DatasetDict({
    train: Dataset({
        features: ['Index', 'Image_0', 'Image_1', 'Question_0', 'Image_0_Question_0', 'Image_1_Question_0', 'Question_1', 'Image_0_Question_1', 'Image_1_Question_1', 'Question Type', 'Source'],
        num_rows: 1900
    })
})
```

### Data Fields

Name | Explanation
--- | ---
`Index`       | **Description:** the unique ID of an example. **Data type:** string
`Source`       | **Description:**  Refers to the origin of the data used for construction. **Data type:** string
`Question Type`       | **Description:** specifies the type of data sample, indicating the question type as "yes or no" or "multiple choice". Additionally, it specifies the language type such as "English", "Chinese", or "Hindi". **Data type:** string
`Question_0`       | **Description:** the first question, which might be of the "yes or no" or "multiple choice" type. **Data type:** string
`Question_1`       | **Description:** the second question, which might be of the "yes or no" or "multiple choice" type. **Data type:** string
`Image_0`       | **Description:** the first image. **Data type:** PIL.JpegImagePlugin.JpegImageFile
`Image_0_Question_0`       | **Description:** groundtruth answer for qustion_0 based on image0 **Data type:** string
`Image_1_Question_0`       | **Description:** groundtruth answer for qustion_1 based on image0. **Data type:** string
`Image_1`       | **Description:** the second image. **Data type:** PIL.JpegImagePlugin.JpegImageFile
`Image_0_Question_1`       | **Description:**  groundtruth answer for qustion_0 based on image1. **Data type:** string
`Image_1_Question_1`       | **Description:** groundtruth answer for qustion_1 based on image1. **Data type:** string


<!-- ### Statistics -->


## Data Source

### Images

Collected from Flicker30k [[1](https://openaccess.thecvf.com/content_iccv_2015/html/Plummer_Flickr30k_Entities_Collecting_ICCV_2015_paper.html)], DOCCI [[2](https://arxiv.org/abs/2404.19753)], XM3600 [[3](https://arxiv.org/abs/2205.12522)].

### Questions and Answers

Generated by GPT4.

## Dataset Construction

### Overall Process
<div align="center">
  <img src="https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/collection.jpg?download=true" style="width: 80%; height: auto;">
</div>
<!-- ![image/jpg](https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/collection.jpg?download=true) -->
We use a semi-automated procedure to collect NaturalBench from natural image-text corpora like Flickr30K. 
- First, we identify confounding pairs of image-text samples that fail discriminative VLMs like CLIP and BLIP2, e.g., they wrongly match an image with another image's caption. 
- Next, we prompt ChatGPT (or GPT4-Vision) to design questions that yield different answers for each image, providing the original captions (or images) in the prompt.
-  We hire human annotators to filter out incorrect or irrelevant VQA samples, such as ``{\it Is the motorcyclist wearing a red and white uniform?}'', which has an identical answer of ``Yes'' for both images. Unlike previous adversarial benchmarks, NaturalBench does not target any specific VQA models nor perturb the images or questions. 

### Prompts for Question Generation:

#### "yes-or-no" type question:
<div align="center">
  <img src="https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/prompt_yes_no.jpg?download=true" style="width: 80%; height: auto;">
</div>
<!-- ![image/jpg](https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/prompt_yes_no.jpg?download=true) -->

#### Multiple choice type question:
<div align="center">
  <img src="https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/prompt_mcq.jpg?download=true" style="width: 80%; height: auto;">
</div>
<!-- ![image/jpg](https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/prompt_mcq.jpg?download=true) -->

<!-- <h1 id="目标部分">目标部分</h1> -->

<h2 id="Leaderboard">Leaderboard</h2>
<div align="center">
  <img src="https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/evaluation.jpg?download=true" style="width: 80%; height: auto;">
</div>
<!-- ![image/jpg](https://huggingface.co/datasets/BaiqiL/NaturalBench/resolve/main/pictures/evaluation.jpg?download=true) -->

<!-- # Considerations for Using the Data

## Social Impact of Dataset

We introduce **NaturalBench** to evaluate vision-language models on their natural adversarial samples -- samples that challenge models significantly more than humans. Unlike previous benchmarks where ``blind'' models could succeed without the images, NaturalBench better reflects VLMs' genuine progress by penalizing solutions that ignore images. Furthermore, NaturalBench offers comprehensive skill tags to assess compositional reasoning abilities and highlights model biases in VLMs. Lastly, we show that our semi-automated method for benchmark curation can adapt to new data sources, facilitating future dynamic evaluations of VLMs.

## Discussion of Biases

Efforts were made to minimize the amount of NSFW and toxic content present in the dataset by having human annotators filter it.

## Other Known Limitations

Our collected samples may inherit biases from web-scraped datasets and foundation models, making human verification crucial. While this work focuses on model performance for individual skill tags, future work may analyze performance using combinations of skills. -->

## Licensing Information

apache-2.0

<!-- ## Citation Information

```

``` -->

<!-- # Authorship -->

<!-- Baiqi Li<sup>1*</sup>,   Zhiqiu Lin<sup>1*</sup>,  Wenxuan Peng<sup>1*</sup>,  Jean de Dieu Nyandwi<sup>1*</sup>, Daniel Jiang<sup>1</sup>, Zixian Ma<sup>2</sup>,  Simran Khanuja<sup>1</sup>,  Ranjay Krishna<sup>2†</sup>,  Graham Neubig<sup>1†</sup>,  Deva Ramanan<sup>1†</sup>  \
<sup>1</sup>Carnegie Mellon University,  <sup>2</sup>University of Washington -->


## Author Statement
We bear all responsibilities in case of violation of rights.

## Maintenance

We will continuously update the NaturalBench benchmark. If you have any questions about the dataset or notice any issues, please feel free to contact [Baiqi Li](mailto:libaiqi123@gmail.com) or [Zhiqiu Lin](mailto:zhiqiul@andrew.cmu.edu). Our team is committed to maintaining this dataset in the long run to ensure its quality!


<!-- <font color="gray">

## <font color="gray">More Questions about Dataset:

### <font color="gray">Are there any errors, sources of noise, or redundancies in the dataset?

None

### <font color="gray">Is the dataset self-contained, or does it link to or otherwise rely on external resources (e.g., websites, tweets, other datasets)?

The dataset is self-contained.

### <font color="gray">Does the dataset contain data that might be considered confidential (e.g., data that is protected by legal privilege or by doctor-patient confidentiality, data that includes the content of individuals non-public communications)? If so, please provide a description.

There is no private data in the dataset. Personally identifiable information has been removed from the data.
</font>

### <font color="gray">[Croissant metadata]()</font> (We will release the NaturalBench dataset within the next two weeks, and it will be accessible through the Huggingface homepage for Croissant metadata.) -->