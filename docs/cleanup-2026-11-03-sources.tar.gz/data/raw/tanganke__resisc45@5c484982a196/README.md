---
dataset_info:
  features:
  - name: image
    dtype: image
  - name: label
    dtype:
      class_label:
        names:
          '0': airplane
          '1': airport
          '2': baseball diamond
          '3': basketball court
          '4': beach
          '5': bridge
          '6': chaparral
          '7': church
          '8': circular farmland
          '9': cloud
          '10': commercial area
          '11': dense residential
          '12': desert
          '13': forest
          '14': freeway
          '15': golf course
          '16': ground track field
          '17': harbor
          '18': industrial area
          '19': intersection
          '20': island
          '21': lake
          '22': meadow
          '23': medium residential
          '24': mobile home park
          '25': mountain
          '26': overpass
          '27': palace
          '28': parking lot
          '29': railway
          '30': railway station
          '31': rectangular farmland
          '32': river
          '33': roundabout
          '34': runway
          '35': sea ice
          '36': ship
          '37': snowberg
          '38': sparse residential
          '39': stadium
          '40': storage tank
          '41': tennis court
          '42': terrace
          '43': thermal power station
          '44': wetland
  splits:
  - name: train
    num_bytes: 246710368.7
    num_examples: 18900
  - name: test
    num_bytes: 87460774.8
    num_examples: 6300
  - name: contrast
    num_bytes: 67512032.7
    num_examples: 6300
  - name: gaussian_noise
    num_bytes: 116440617.3
    num_examples: 6300
  - name: impulse_noise
    num_bytes: 125449913.4
    num_examples: 6300
  - name: jpeg_compression
    num_bytes: 85196403.6
    num_examples: 6300
  - name: motion_blur
    num_bytes: 73908158.1
    num_examples: 6300
  - name: pixelate
    num_bytes: 5573022.0
    num_examples: 6300
  - name: spatter
    num_bytes: 109007915.1
    num_examples: 6300
  download_size: 911199338
  dataset_size: 917259205.7
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: test
    path: data/test-*
  - split: contrast
    path: data/contrast-*
  - split: gaussian_noise
    path: data/gaussian_noise-*
  - split: impulse_noise
    path: data/impulse_noise-*
  - split: jpeg_compression
    path: data/jpeg_compression-*
  - split: motion_blur
    path: data/motion_blur-*
  - split: pixelate
    path: data/pixelate-*
  - split: spatter
    path: data/spatter-*
---

# [RESISC45](https://www.tensorflow.org/datasets/catalog/resisc45)

## Overview

## Usage

```python
from datasets import load_dataset

# Load the dataset
dataset = load_dataset('tanganke/resisc45')
```

## Dataset Information

The dataset is divided into the following splits:

- **Training set**: Contains 18,900 examples, used for model training.
- **Test set**: Contains 6,300 examples, used for model evaluation and benchmarking.

The dataset also includes the following augmented sets, which can be used for testing the model's robustness to various types of image corruptions:

- **Contrast-enhanced set**: Contains 6,300 examples with enhanced contrast for improved feature visibility.
- **Gaussian noise set**: Contains 6,300 examples where images have been corrupted with Gaussian noise.
- **Impulse noise set**: Contains 6,300 examples with impulse noise.
- **JPEG compression set**: Contains 6,300 examples where images have been compressed using JPEG encoding.
- **Motion blur set**: Contains 6,300 examples with motion blur applied.
- **Pixelate set**: Contains 6,300 examples where images have been pixelated.
- **Spatter set**: Contains 6,300 examples with spatter noise.

