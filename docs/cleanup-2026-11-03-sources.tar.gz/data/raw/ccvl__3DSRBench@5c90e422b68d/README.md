---
license: cc-by-4.0
task_categories:
- visual-question-answering
language:
- en
tags:
- spatial-reasoning
- 3D-VQA
pretty_name: 3dsrbench
size_categories:
- 1K<n<10K
configs:
- config_name: benchmark
  data_files:
  - split: test
    path: 3dsrbench_v1-00000-of-00001.parquet
---

# 3DSRBench: A Comprehensive 3D Spatial Reasoning Benchmark

<a href="https://arxiv.org/abs/2412.07825" target="_blank">
    <img alt="arXiv" src="https://img.shields.io/badge/arXiv-3DSRBench-red?logo=arxiv" height="20" />
</a>
<a href="https://3dsrbench.github.io/" target="_blank">
    <img alt="Webpage" src="https://img.shields.io/badge/%F0%9F%8C%8E_Website-3DSRBench-green.svg" height="20" />
</a>

We present 3DSRBench, a new 3D spatial reasoning benchmark that significantly advances the evaluation of 3D spatial reasoning capabilities of LMMs by manually annotating 2,100 VQAs on MS-COCO images and 672 on multi-view synthetic images rendered from HSSD. Experimental results on different splits of our 3DSRBench provide valuable findings and insights that will benefit future research on 3D spatially intelligent LMMs.

<img alt="teaser" src="https://3dsrbench.github.io/assets/images/teaser.png" style="width: 100%; max-width: 800px;" />

## Files

We list all provided files as follows. Note that to reproduce the benchmark results, you only need **`3dsrbench_v1_vlmevalkit_circular.tsv`** and the script **`compute_3dsrbench_results_circular.py`**, as demonstrated in the [evaluation section](#evaluation).

1. **`3dsrbench_v1.csv`**: raw 3DSRBench annotations.
2. **`3dsrbench_v1_vlmevalkit.tsv`**: VQA data with question and choices processed with flip augmentation (see paper Sec 3.4); **NOT** compatible with the [VLMEvalKit](https://github.com/open-compass/VLMEvalKit) data format.
3. **`3dsrbench_v1_vlmevalkit_circular.tsv`**: **`3dsrbench_v1_vlmevalkit.tsv`** augmented with circular evaluation; compatible with the [VLMEvalKit](https://github.com/open-compass/VLMEvalKit) data format.
4. **`compute_3dsrbench_results_circular.py`**: helper script that the outputs of VLMEvalKit and produces final performance.
5. **`coco_images.zip`**: all [MS-COCO](https://cocodataset.org/) images used in our 3DSRBench.
6. **`3dsrbench_v1-00000-of-00001.parquet`**: **`parquet`** file compatible with [HuggingFace datasets](https://huggingface.co/docs/datasets/en/index).

## Usage

**I. With HuggingFace datasets library.**

```py
from datasets import load_dataset
dataset = load_dataset('ccvl/3DSRBench')
```

**II. With VLMEvalKit.** See [evaluation section](#evaluation).

## Benchmark

We provide benchmark results for **GPT-4o** and **Gemini 1.5 Pro** on our 3DSRBench. *More benchmark results to be added.*

| Model | Overall | Height | Location | Orientation | Multi-Object |
|:-|:-:|:-:|:-:|:-:|:-:|
|GPT-4o|44.6|51.6|60.1|21.4|40.2|
|Gemini 1.5 Pro|50.3|52.5|65.0|36.2|43.3|
|Gemini 2.0 Flash|49.8|49.7|68.9|32.2|41.5|
|Qwen VL Max|52.4|45.5|70.5|39.7|44.8|
|||||
|LLaVA v1.5 7B|38.1|39.1|46.9|28.7|34.7|
|Cambrian 8B|42.2|23.2|53.9|35.9|41.9|
|LLaVA NeXT 8B|48.4|50.6|59.9|36.1|43.4|


## Evaluation

We follow the data format in [VLMEvalKit](https://github.com/open-compass/VLMEvalKit) and provide **`3dsrbench_v1_vlmevalkit_circular.tsv`**, which processes the outputs of VLMEvalKit and produces final performance.
The step-by-step evaluation is as follows:

```sh
python3 run.py --data 3DSRBenchv1 --model GPT4o_20240806
python3 compute_3dsrbench_results_circular.py
```

## Citation

```
@article{ma20243dsrbench,
  title={3DSRBench: A Comprehensive 3D Spatial Reasoning Benchmark},
  author={Ma, Wufei and Chen, Haoyu and Zhang, Guofeng and de Melo, Celso M and Yuille, Alan and Chen, Jieneng},
  journal={arXiv preprint arXiv:2412.07825},
  year={2024}
}
```