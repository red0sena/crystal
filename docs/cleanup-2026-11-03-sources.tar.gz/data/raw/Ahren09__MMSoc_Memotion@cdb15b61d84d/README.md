---
dataset_info:
  features:
  - name: image
    dtype: image
  - name: text_ocr
    dtype: string
  - name: text_corrected
    dtype: string
  - name: humor
    dtype: string
  - name: sarcasm
    dtype: string
  - name: offensive
    dtype: string
  - name: motivational
    dtype: string
  - name: sentiment
    dtype: string
  - name: split
    dtype: string
  splits:
  - name: train
    num_bytes: 566317641.183
    num_examples: 5593
  - name: validation
    num_bytes: 70907543.0
    num_examples: 699
  - name: test
    num_bytes: 75612731.0
    num_examples: 700
  download_size: 735937708
  dataset_size: 712837915.183
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: validation
    path: data/validation-*
  - split: test
    path: data/test-*
---
